<template>
      <h2>{{ friendName }}</h2>
    <div class="messages" ref="messageRef">
           <div v-for="(message,index) in messages" :key="index" class="message">
              <div v-if="message.sender === userId" class="user-them">
                {{friendName}}: {{message.text}}
              </div>
              <div v-else class="user-self"> 
                You: {{message.text}}
              </div>
         </div>          
    </div>
      <form>
  <div class="messaging-panel">
          <font-awesome-icon class="bom" icon="fa-solid fa-terminal" size="lg" />
           <input type="text" placeholder="text" v-model="text">
           <button @click.prevent="sendMessage(text)">+</button>
          </div>
      </form>
    </template>
    <script>
    
import {ref,onMounted,nextTick} from 'vue';
import socket from '../socket';
const text = ref('');
const messages = ref([]);
const messageRef = ref(null);
socket.on("private message", ({ message, from }) => {
      console.log("MEEESAAGE ",from);
      console.log("IDDD ",message);
          messages.value.push({text:message,sender:from});
    });
export default {
        props:['userId','friendName'],
        
        setup(){
            return {messages,messageRef,text}
        },
      mounted(){
    console.log("ssssssssssssssssssssss");
    fetch("http://localhost:3000/chat/messages",{
        method:"POST",
        headers:{
          "Content-Type":"application/json",
          "Authorization":"Bearer " + this.state.userToken
        },
        body:JSON.stringify({
          recieverId:this.userId
        })
      }).then(res=>{
        return res.json()
      }).then(response=>{
          console.log("RETURNED MESSAGES  ====>  ")
          console.log(response)
          messages.value = response.messages
      }).catch(err=>{
        console.log(err);
      });

  },
  
  methods:{	
    
    sendMessage:async function(message){
          socket.emit("private message", {
              message,
              to: this.userId,
              from:this.state.myUserId
        });
			messages.value.push({text:message,sender:this.state.myUserId});
			await nextTick();
			messageRef.value.scrollTop = messageRef.value.scrollHeight;
      text.value = '';
            }
        }
    }
    
    
    // TO DO  meesageRef.value.scrollTop = messageRef.value.scrollHeight
    
    </script>
    
    <style>



form .messaging-panel{
  display: flex;
  bottom: 70px;
  width:100%;
}
form .messaging-panel button{
  position: relative;
  margin-left: 20px;
  background-color: transparent;
  border: none;
  color:white;
  font-size: 30px;
  cursor: pointer;
  top: 10px;
  
}
.messages{
  height: 600px;
  background-color: transparent;
}
.messages .message{
  padding: 5px;
  position: relative;
  margin-bottom: 30px;
}



.user-self{
  padding: 5px;
  position: absolute;
  margin-bottom:30px;
  width: fit-content;
  border-top-right-radius: 15px;
  background-color: white;
}

.user-them{
  padding: 5px;
  width: fit-content;
  position: absolute;
  margin-bottom: 30px;
  right: 5px;
  border-top-left-radius: 15px;
  background-color: orange;
}

    </style>